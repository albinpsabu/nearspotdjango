from django.db import transaction
from asgiref.sync import async_to_sync
from channels.layers import get_channel_layer

from rest_framework import generics
from rest_framework.response import Response
from rest_framework.exceptions import ValidationError
from rest_framework.views import APIView
from accounts.permissions import IsAdmin, IsUser,IsAdminOrEmployee
from rest_framework.permissions import AllowAny,IsAuthenticated
from django.shortcuts import get_object_or_404
from django.db import transaction
from django.db.models import Count, Q
from rest_framework import status
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from rest_framework.exceptions import PermissionDenied

from .models import (
    Category,
    HiddenSpot,
    Verification,
    Report,
    CommunityVerification,
    SpotMedia,
    AuditLog,
    Review,
    SavedSpot,
    Notification


)
from django.contrib.gis.geos import Point
from django.contrib.gis.db.models.functions import Distance
from django.contrib.gis.measure import D



from .serializers import (
    CategorySerializer,
    HiddenSpotSerializer,
    PendingSpotSerializer,
    VerificationSerializer,
    ApprovedSpotSerializer,
    MySpotSerializer,
    ReportSerializer,
    ReportStatusSerializer,
    CommunityVerificationSerializer,
    CommunitySpotSerializer,
    SpotMediaSerializer,
    AuditLogSerializer,
    ReviewSerializer,
    SavedSpotSerializer,
    SavedSpotListSerializer,
    MyReviewSerializer,
    NotificationSerializer,

)

def notify_spot_owner(spot, notification_type, message):
    def send_notification():
        notification_titles = {
            "spot.pending": "Spot Submitted",
            "spot.approved": "Spot Approved",
            "spot.rejected": "Spot Rejected",
        }

        notification = Notification.objects.create(
            recipient_id=spot.submitted_by_id,
            notification_type=notification_type,
            title=notification_titles.get(
                notification_type,
                "Spot Update",
            ),
            message=message,
            spot=spot,
        )

        channel_layer = get_channel_layer()

        if channel_layer is None:
            return

        async_to_sync(channel_layer.group_send)(
            f"spot_user_{spot.submitted_by_id}",
            {
                "type": "user.notification",
                "notification_type": notification_type,
                "data": {
                    "id": notification.pk,
                    "spot_id": spot.pk,
                    "name": spot.name,
                    "status": spot.status,
                    "title": notification.title,
                    "message": notification.message,
                    "rejection_reason": spot.rejection_reason,
                    "is_read": notification.is_read,
                    "created_at": notification.created_at.isoformat(),
                },
            },
        )

    transaction.on_commit(send_notification)



class CategoryListCreateView(generics.ListCreateAPIView):

    queryset = Category.objects.all()
    serializer_class = CategorySerializer

    def get_permissions(self):

        if self.request.method == "GET":
            return []

        return [IsAdmin()]
    



class CategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    permission_classes = [IsAdmin]

    def perform_destroy(self, instance):
        if instance.spots.exists():
            from rest_framework.exceptions import ValidationError

            raise ValidationError({
                "error": "This category cannot be deleted because it is being used by one or more spots."
            })

        instance.delete()


class HiddenSpotCreateView(generics.CreateAPIView):

    queryset = HiddenSpot.objects.all()
    serializer_class = HiddenSpotSerializer
    permission_classes = [IsUser]


# ============================================================
# EMPLOYEE SPOT REVIEW - LIST SUBMISSIONS
# ============================================================

class PendingSpotListView(generics.ListAPIView):

    serializer_class = PendingSpotSerializer
    permission_classes = [IsAdminOrEmployee]

    def get_queryset(self):
        return (
            HiddenSpot.objects
            .filter(status=HiddenSpot.Status.PENDING)
            .select_related(
                "category",
                "submitted_by"
            )
            .prefetch_related("media")
            .order_by("-created_at")
        )


# ============================================================
# EMPLOYEE SPOT REVIEW - INSPECT ONE SUBMISSION
# ============================================================

class EmployeeSpotDetailView(generics.RetrieveAPIView):

    serializer_class = PendingSpotSerializer
    permission_classes = [IsAdminOrEmployee]
    lookup_field = "pk"

    def get_queryset(self):
        return (
            HiddenSpot.objects
            .select_related(
                "category",
                "submitted_by"
            )
            .prefetch_related("media")
        )

class ApprovedSpotDetailView(generics.RetrieveAPIView):
    serializer_class = ApprovedSpotSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        return (
            HiddenSpot.objects
            .filter(status=HiddenSpot.Status.APPROVED)
            .select_related("category")
            .prefetch_related("media")
        )


class RejectSpotView(APIView):

    permission_classes = [IsAdminOrEmployee]

    def post(self, request, pk):

        try:
            spot = HiddenSpot.objects.get(pk=pk)
        except HiddenSpot.DoesNotExist:
            return Response(
                {"error": "Spot not found."},
                status=404
            )

        if spot.status != HiddenSpot.Status.PENDING:
            return Response(
                {
                    "error": "Only pending spots can be rejected."
                },
                status=400
            )

        reason = request.data.get("reason")

        if not reason:
            return Response(
                {
                    "error": "Rejection reason is required."
                },
                status=400
            )

        spot.status = HiddenSpot.Status.REJECTED
        spot.rejection_reason = reason
        spot.save()

        verification = Verification.objects.create(
            spot=spot,
            employee=request.user,
            action=Verification.Action.REJECTED,
            reason=reason
        )

        AuditLog.objects.create(
            user=request.user,
            action="SPOT_REJECTED",
            description=f"Spot '{spot.name}' (ID: {spot.id}) was rejected. Reason: {reason}",
        )
        notify_spot_owner(
            spot,
            "spot.rejected",
            "Your spot submission has been rejected.",
        )

        return Response(
            {
                "message": "Spot rejected successfully.",
                "spot_id": spot.id,
                "status": spot.status,
                "reason": reason,
                "verification_id": verification.id,
            }
        )

    
class ApproveSpotView(APIView):

    permission_classes = [IsAdminOrEmployee]

    def post(self, request, pk):

        try:
            spot = HiddenSpot.objects.get(pk=pk)
        except HiddenSpot.DoesNotExist:
            return Response(
                {"error": "Spot not found."},
                status=404
            )

        if spot.status != HiddenSpot.Status.PENDING:
            return Response(
                {
                    "error": "Only pending spots can be approved."
                },
                status=400
            )

        with transaction.atomic():

            spot.status = HiddenSpot.Status.APPROVED
            spot.rejection_reason = ""
            spot.save()

            verification = Verification.objects.create(
                spot=spot,
                employee=request.user,
                action=Verification.Action.APPROVED,
                reason=""
            )
            AuditLog.objects.create(
                user=request.user,
                action="SPOT_APPROVED",
                description=f"Spot '{spot.name}' (ID: {spot.id}) was approved.",
            )
        print(
           
            f"{spot.submitted_by_id} for spot ID {spot.pk}"
        )            

        notify_spot_owner(
            spot,
            "spot.approved",
            "Your spot submission has been approved.",
        )


        return Response(
            {
                "message": "Spot approved successfully.",
                "spot_id": spot.id,
                "status": spot.status,
                "verification_id": verification.id,
            }
        )


class ApprovedSpotListView(generics.ListAPIView):

    serializer_class = ApprovedSpotSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):

        return (
            HiddenSpot.objects
            .filter(
                status=HiddenSpot.Status.APPROVED
            )
            .select_related(
                "category"
            )
            .order_by(
                "-created_at"
            )
        )





class NearbySpotListView(generics.ListAPIView):
    serializer_class = ApprovedSpotSerializer
    permission_classes = [AllowAny]

    def get_queryset(self):
        latitude_param = self.request.query_params.get("latitude")
        longitude_param = self.request.query_params.get("longitude")
        radius_param = self.request.query_params.get("radius", "5000")

        if latitude_param is None or longitude_param is None:
            raise ValidationError({
                "error": "latitude and longitude are required."
            })

        try:
            latitude = float(latitude_param)
            longitude = float(longitude_param)
            radius = float(radius_param)
        except (TypeError, ValueError):
            raise ValidationError({
                "error": "latitude, longitude, and radius must be valid numbers."
            })

        if not -90 <= latitude <= 90:
            raise ValidationError({
                "latitude": "Latitude must be between -90 and 90."
            })

        if not -180 <= longitude <= 180:
            raise ValidationError({
                "longitude": "Longitude must be between -180 and 180."
            })

        if radius <= 0:
            raise ValidationError({
                "radius": "Radius must be greater than 0."
            })

        user_location = Point(
            longitude,
            latitude,
            srid=4326
        )

        return (
            HiddenSpot.objects
            .filter(
                status=HiddenSpot.Status.APPROVED,
                location__distance_lte=(
                    user_location,
                    D(m=radius)
                )
            )
            .annotate(
                distance=Distance(
                    "location",
                    user_location
                )
            )
            .select_related("category")
            .order_by("distance")
        )

class MySpotListView(generics.ListAPIView):
    serializer_class = MySpotSerializer
    permission_classes = [IsUser]

    def get_queryset(self):
        return (
            HiddenSpot.objects
            .filter(
                submitted_by=self.request.user
            )
            .select_related("category")
            .order_by("-created_at")
        )



class MySpotUpdateView(generics.UpdateAPIView):
    serializer_class = HiddenSpotSerializer
    permission_classes = [IsUser]

    def get_queryset(self):
        return HiddenSpot.objects.filter(
            submitted_by=self.request.user,
            status=HiddenSpot.Status.PENDING
        )


class CancelSpotView(APIView):
    permission_classes = [IsUser]

    def post(self, request, pk):
        try:
            spot = HiddenSpot.objects.get(
                pk=pk,
                submitted_by=request.user
            )
        except HiddenSpot.DoesNotExist:
            return Response(
                {"error": "Spot not found."},
                status=404
            )

        if spot.status != HiddenSpot.Status.PENDING:
            return Response(
                {
                    "error": "Only pending spots can be cancelled."
                },
                status=400
            )

        spot.status = HiddenSpot.Status.CANCELLED
        spot.save()

        return Response({
            "message": "Spot cancelled successfully.",
            "spot_id": spot.id,
            "status": spot.status,
        })




class ReportSpotView(generics.CreateAPIView):
    serializer_class = ReportSerializer
    permission_classes = [IsUser]

    def perform_create(self, serializer):
        serializer.save(reported_by=self.request.user)





class ReportListView(generics.ListAPIView):
    serializer_class = ReportSerializer
    permission_classes = [IsAdminOrEmployee]

    def get_queryset(self):
        return (
            Report.objects
            .select_related("spot", "reported_by")
            .order_by("-created_at")
        )



class ReportStatusUpdateView(generics.UpdateAPIView):
    queryset = Report.objects.all()
    serializer_class = ReportStatusSerializer
    permission_classes = [IsAdminOrEmployee]

    http_method_names = ["patch"]

    def perform_update(self, serializer):
        report = serializer.save()

        AuditLog.objects.create(
            user=self.request.user,
            action="REPORT_STATUS_UPDATED",
            description=(
                f"Report ID {report.id} for spot "
                f"'{report.spot.name}' was changed to "
                f"{report.status}."
            ),
        )



class CommunityVerificationCreateView(generics.CreateAPIView):
    serializer_class = CommunityVerificationSerializer
    permission_classes = [IsUser]

    def perform_create(self, serializer):
        spot = serializer.validated_data["spot"]

        if spot.submitted_by == self.request.user:
            from rest_framework.exceptions import ValidationError

            raise ValidationError(
                {"spot": "You cannot verify your own spot."}
            )

        serializer.save(user=self.request.user)



class CommunitySpotListView(generics.ListAPIView):
    serializer_class = CommunitySpotSerializer
    permission_classes = [IsUser]

    def get_queryset(self):
        return (
            HiddenSpot.objects
            .filter(status=HiddenSpot.Status.PENDING)
            .exclude(submitted_by=self.request.user)
            .select_related("category")
            .order_by("-created_at")
        )




class CommunityVerificationSummaryView(APIView):
    permission_classes = [IsUser]

    def get(self, request, pk):
        try:
            spot = HiddenSpot.objects.get(
                pk=pk,
                status=HiddenSpot.Status.APPROVED
            )
        except HiddenSpot.DoesNotExist:
            return Response(
                {"error": "Approved spot not found."},
                status=404
            )

        summary = CommunityVerification.objects.filter(
            spot=spot
        ).aggregate(
            confirm_count=Count(
                "id",
                filter=Q(
                    action=CommunityVerification.Action.CONFIRM
                )
            ),
            report_count=Count(
                "id",
                filter=Q(
                    action=CommunityVerification.Action.REPORT
                )
            ),
        )

        confirm_count = summary["confirm_count"] or 0
        report_count = summary["report_count"] or 0

        if confirm_count > report_count:
            community_status = "CONFIRMED"
        elif report_count > confirm_count:
            community_status = "REPORTED"
        else:
            community_status = "NEUTRAL"

        return Response({
            "spot_id": spot.id,
            "confirm_count": confirm_count,
            "report_count": report_count,
            "community_status": community_status,
        })


class SpotMediaUploadView(generics.CreateAPIView):
    serializer_class = SpotMediaSerializer
    permission_classes = [IsUser]

    def perform_create(self, serializer):
        spot = serializer.validated_data["spot"]

        # Only the owner can upload media
        if spot.submitted_by != self.request.user:
            from rest_framework.exceptions import PermissionDenied

            raise PermissionDenied(
                "You can upload media only to your own spots."
            )

        # Media can only be added while the spot is pending
        if spot.status != HiddenSpot.Status.PENDING:
            from rest_framework.exceptions import ValidationError

            raise ValidationError({
                "spot": "Media can only be uploaded while the spot is pending."
            })

        serializer.save()




class AdminSpotListView(generics.ListAPIView):
    queryset = (
        HiddenSpot.objects
        .select_related("category", "submitted_by")
        .order_by("-created_at")
    )
    serializer_class = MySpotSerializer
    permission_classes = [IsAdmin]





class AdminSpotDeleteView(generics.DestroyAPIView):
    queryset = HiddenSpot.objects.all()
    permission_classes = [IsAdmin]

    def perform_destroy(self, instance):
        AuditLog.objects.create(
            user=self.request.user,
            action="SPOT_DELETED",
            description=(
                f"Spot '{instance.name}' "
                f"(ID: {instance.id}) was deleted."
            ),
        )

        instance.delete()

        



class AdminSpotStatusView(generics.UpdateAPIView):
    queryset = HiddenSpot.objects.all()
    serializer_class = MySpotSerializer
    permission_classes = [IsAdmin]

    def update(self, request, *args, **kwargs):
        spot = self.get_object()
        old_status = spot.status
        new_status = request.data.get("status")

        allowed_statuses = [
            HiddenSpot.Status.PENDING,
            HiddenSpot.Status.APPROVED,
            HiddenSpot.Status.REJECTED,
            HiddenSpot.Status.CANCELLED,
        ]

        if new_status not in allowed_statuses:
            return Response(
                {
                    "error": "Invalid status.",
                    "allowed_statuses": allowed_statuses,
                },
                status=400,
            )

        spot.status = new_status

        if new_status != HiddenSpot.Status.REJECTED:
            spot.rejection_reason = ""

        spot.save()
        if new_status == HiddenSpot.Status.APPROVED:
            notify_spot_owner(
                spot,
                "spot.approved",
                "Your spot submission has been approved.",
            )
        elif new_status == HiddenSpot.Status.REJECTED:
            notify_spot_owner(
                spot,
                "spot.rejected",
                (
                    f"Your spot submission was rejected. "
                    f"Reason: {spot.rejection_reason or 'No reason provided.'}"
                ),
            )


        AuditLog.objects.create(
            user=request.user,
            action="SPOT_STATUS_UPDATED",
            description=(
                f"Spot '{spot.name}' (ID: {spot.id}) "
                f"status changed from {old_status} to {new_status}."
            ),
        )

        return Response(
            MySpotSerializer(
                spot,
                context={"request": request},
            ).data
        )


    
class AuditLogListView(generics.ListAPIView):
    queryset = (
        AuditLog.objects
        .select_related("user")
        .order_by("-created_at")
    )
    serializer_class = AuditLogSerializer
    permission_classes = [IsAdmin]




# ============================================================
# EMPLOYEE DASHBOARD - DATABASE-BACKED STATISTICS
# ============================================================

class EmployeeDashboardStatsView(APIView):

    permission_classes = [IsAdminOrEmployee]

    def get(self, request):

        # --------------------------------------------
        # SPOT STATISTICS
        # --------------------------------------------

        spot_stats = HiddenSpot.objects.aggregate(
            total=Count("id"),
            pending=Count(
                "id",
                filter=Q(status=HiddenSpot.Status.PENDING)
            ),
            approved=Count(
                "id",
                filter=Q(status=HiddenSpot.Status.APPROVED)
            ),
            rejected=Count(
                "id",
                filter=Q(status=HiddenSpot.Status.REJECTED)
            ),
            cancelled=Count(
                "id",
                filter=Q(status=HiddenSpot.Status.CANCELLED)
            ),
        )

        # --------------------------------------------
        # REPORT STATISTICS
        # --------------------------------------------

        report_stats = Report.objects.aggregate(
            total=Count("id"),
            pending=Count(
                "id",
                filter=Q(status=Report.Status.PENDING)
            ),
            reviewed=Count(
                "id",
                filter=Q(status=Report.Status.REVIEWED)
            ),
            resolved=Count(
                "id",
                filter=Q(status=Report.Status.RESOLVED)
            ),
        )

        # --------------------------------------------
        # CURRENT EMPLOYEE'S REVIEW ACTIVITY
        # --------------------------------------------

        review_stats = Verification.objects.filter(
            employee=request.user
        ).aggregate(
            total_reviews=Count("id"),
            approved=Count(
                "id",
                filter=Q(
                    action=Verification.Action.APPROVED
                )
            ),
            rejected=Count(
                "id",
                filter=Q(
                    action=Verification.Action.REJECTED
                )
            ),
        )

        # --------------------------------------------
        # RECENT REVIEWS BY CURRENT EMPLOYEE
        # --------------------------------------------

        recent_reviews = (
            Verification.objects
            .filter(employee=request.user)
            .select_related("spot")
            .order_by("-created_at")[:5]
        )

        recent_activity = [
            {
                "verification_id": review.id,
                "spot_id": review.spot_id,
                "spot_name": review.spot.name,
                "action": review.action,
                "reason": review.reason,
                "created_at": review.created_at,
            }
            for review in recent_reviews
        ]

        # --------------------------------------------
        # API RESPONSE
        # --------------------------------------------

        return Response({
            "employee": {
                "id": request.user.id,
                "name": request.user.name,
                "email": request.user.email,
                "role": request.user.role,
            },
            "spots": spot_stats,
            "reports": report_stats,
            "my_reviews": review_stats,
            "recent_activity": recent_activity,
        })




# ============================================================
# REVIEW VIEWS
# ============================================================
class ReviewListCreateView(generics.ListCreateAPIView):
    """GET /spots/<pk>/reviews/ — list
       POST /spots/<pk>/reviews/ — create"""
    serializer_class = ReviewSerializer
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    def get_permissions(self):
        if self.request.method == "POST":
            return [IsUser()]
        return [AllowAny()]
    def get_queryset(self):
        spot = get_object_or_404(HiddenSpot, pk=self.kwargs["pk"], status=HiddenSpot.Status.APPROVED)
        return Review.objects.filter(spot=spot).select_related("user").prefetch_related("media").order_by("-created_at")
    def perform_create(self, serializer):
        spot = get_object_or_404(HiddenSpot, pk=self.kwargs["pk"], status=HiddenSpot.Status.APPROVED)
        serializer.save(spot=spot, user=self.request.user)
class ReviewDetailView(generics.RetrieveUpdateDestroyAPIView):
    """GET/PUT/PATCH/DELETE /spots/<pk>/reviews/<review_pk>/"""
    serializer_class = ReviewSerializer
    parser_classes = [MultiPartParser, FormParser, JSONParser]
    permission_classes = [IsUser]
    lookup_url_kwarg = "review_pk"
    def get_queryset(self):
        spot = get_object_or_404(HiddenSpot, pk=self.kwargs["pk"], status=HiddenSpot.Status.APPROVED)
        return Review.objects.filter(spot=spot).select_related("user").prefetch_related("media")
    def get_object(self):
        review = super().get_object()
        if self.request.method in ("PUT", "PATCH", "DELETE") and review.user != self.request.user:
            raise PermissionDenied("You can only edit your own reviews.")
        return review
# =========================
# SAVED SPOT VIEWS
# =========================
class SavedSpotListView(generics.ListAPIView):
    """GET /api/spots/saved/ — list current user's saved spots."""
    serializer_class = SavedSpotListSerializer
    permission_classes = [IsUser]
    def get_queryset(self):
        return SavedSpot.objects.filter(user=self.request.user).select_related(
            "spot", "spot__category"
        ).prefetch_related("spot__media").order_by("-saved_at")





# backend/spots/views.py — add this class (e.g., after SavedSpotListView)

class SavedSpotView(APIView):
    """
    POST   /api/spots/<pk>/save/   — save a spot
    DELETE /api/spots/<pk>/save/   — unsave a spot
    """
    permission_classes = [IsUser]

    def post(self, request, pk):
        spot = get_object_or_404(HiddenSpot, pk=pk, status=HiddenSpot.Status.APPROVED)
        saved_spot, created = SavedSpot.objects.get_or_create(spot=spot, user=request.user)
        if not created:
            return Response({"detail": "Spot already saved."}, status=status.HTTP_400_BAD_REQUEST)
        serializer = SavedSpotSerializer(saved_spot, context={"request": request})
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    def delete(self, request, pk):
        spot = get_object_or_404(HiddenSpot, pk=pk)
        deleted, _ = SavedSpot.objects.filter(spot=spot, user=request.user).delete()
        if not deleted:
            return Response({"detail": "Spot not in saved list."}, status=status.HTTP_404_NOT_FOUND)
        return Response(status=status.HTTP_204_NO_CONTENT)






class MyReviewListView(generics.ListAPIView):
    """GET /api/spots/my-reviews/ — list current user's reviews across all spots."""
    serializer_class = MyReviewSerializer
    permission_classes = [IsUser]

    def get_queryset(self):
        return Review.objects.filter(user=self.request.user).select_related(
            "spot", "spot__category"
        ).prefetch_related("media").order_by("-created_at")






class NotificationListView(generics.ListAPIView):
    serializer_class = NotificationSerializer
    permission_classes = [IsAuthenticated]

    def get_queryset(self):
        return (
            Notification.objects
            .filter(recipient=self.request.user)
            .select_related("spot")
            .order_by("-created_at")
        )


class NotificationMarkReadView(APIView):
    permission_classes = [IsAuthenticated]

    def patch(self, request, pk):
        notification = get_object_or_404(
            Notification,
            pk=pk,
            recipient=request.user,
        )

        notification.is_read = True
        notification.save(update_fields=["is_read"])

        return Response({
            "message": "Notification marked as read.",
            "id": notification.pk,
            "is_read": notification.is_read,
        })


class NotificationMarkAllReadView(APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        updated_count = Notification.objects.filter(
            recipient=request.user,
            is_read=False,
        ).update(is_read=True)

        return Response({
            "message": "All notifications marked as read.",
            "updated_count": updated_count,
        })






